import { View } from "react-native";
import { StyleSheet } from "react-native";
import StatusBarCustom from "./components/StatusBarCustom";
import AccountTab from "./components/AccountTab";
import SectionListCustom from "./components/SectionListCustom";
export default function App() {
  return (
    <View>
      <StatusBarCustom />
      <AccountTab />
      <SectionListCustom />
    </View>
  );
}
